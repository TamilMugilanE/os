#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <string.h>

#define FILENAME "sample.txt"

void fork_example()
{
    pid_t pid = fork();
    if (pid == -1)
    {
        perror("fork");
    }
    else if (pid == 0)
    {
        printf("Child process id : %d\n", getpid());
        exit(0);
    }
    else
    {
        printf("Parent process id : %d\n", pid);
        wait(NULL);
    }
}

void getpid_example()
{
    printf("PID of process : %d\n", getpid());
}

void getppid_example()
{
    printf("PPID of process : %d\n", getppid());
}

void sleep_example()
{
    printf("Process is going into sleep\n");
    sleep(3);
    printf("Process is awake");
}

void setpriority_example()
{
    if (setpriority(PRIO_PROCESS, 0, 10) == -1)
    {
        perror("setpriority");
    }
    else
    {
        printf("Priority set to 10\n")
    }
}

void wait_example()
{
    pid_t pid = fork();
    if (pid == -1)
    {
        perror("fork");
    }
    else if (pid == 0)
    {
        printf("Child process exiting\n");
        exit(42);
    }
    else
    {
        int status;
        wait(&status);
        if (WIFEXITED(status))
        {
            printf("Child exited with stats %d\n", WEXITSTATUS(status));
        }
    }
}

void open_example()
{
    int fd = open(FILENAME, O_WRONLY | O_CREAT, 0644);
    if (fd == -1)
    {
        perror("open");
    }
    else
    {
        printf("File opened successfully\n");
        close(fd);
    }
}

void read_example()
{
    int fd = open(FILENAME, O_RDONLY);

    char buffer[100];
    ssize_t bytes_read = read(fd, buffer, sizeof(buffer) - 1);
    buffer[bytes_read] = '\0';
    printf("Read %zd bytes : %s", bytes_read, buffer);
    close(fd)
}

void write_example()
{
    int fd = open(FILENAME, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    const chat *message = "Writing into file";
    ssize_t bytes_wrote = write(fd, message, strlen(message));
}

void close_example(){
    int fd = open(FILENAME, O_RDONLY);
    close(fd);
}

void chmod_example(){
    if (chamod(FILENAME, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH) == -1){
        perror("chmod");
    }
    else{
        printf("File permissions changed successfully\n");
    }
}

int main(){
    int choice;
    while (1) {
        printf("\nSystem Calls Menu:\n");
        printf("1. fork()\n2. exit()\n3. getpid()\n4. getppid()\n5. sleep()\n");
        printf("6. setpriority()\n7. wait()\n8. open()\n9. read()\n10. write()\n");
        printf("11. close()\n12. chmod()\n0. Quit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: fork_example(); break;
            case 2: exit_example(); break;
            case 3: getpid_example(); break;
            case 4: getppid_example(); break;
            case 5: sleep_example(); break;
            case 6: setpriority_example(); break;
            case 7: wait_example(); break;
            case 8: open_example(); break;
            case 9: read_example(); break;
            case 10: write_example(); break;
            case 11: close_example(); break;
            case 12: chmod_example(); break;
            case 0: printf("Exiting program.\n"); return 0;
            default: printf("Invalid choice. Please try again.\n");
        }
    }

    return 0;
}