#Non pre emptive

def calculate_completion_time(n,at,bt):
    ct = [0]*n
    time = 0
    r_processes = list(range(n))

    while r_processes:
        
        a_processes = [process for process in r_processes if at[process] <= time]

        if a_processes:
            next_process = min(a_processes,key=lambda process: bt[process])

        else:
            next_process = min(r_processes,key= lambda process: at[process])
            time = at[next_process]
        
        ct[next_process] = time + bt[next_process]
        time = ct[next_process]

        r_processes.remove(next_process)
    
    return ct


def calculate_tat(n,ct,at):
    tat = [0]*n
    for i in range(n):
        tat[i] = ct[i] - at[i]
    return tat

def calculate_wt(n,tat,bt):
    wt = [0] * n
    for i in range(n):
        wt[i] = tat[i] - bt[i]
    return wt

def sjf_func(processes,at,bt):
    n = len(processes)
    ct = calculate_completion_time(n,at,bt)
    tat = calculate_tat(n,ct,at)
    wt = calculate_wt(n,tat,bt)

    print("Processes\tArrival time\tBurst Time\tCompletion Time\tTurnaround Time\tWaiting time")
    for i in range(n):
        print(f"{processes[i]} \t\t{at[i]} \t\t{bt[i]} \t\t{ct[i]} \t\t{tat[i]} \t\t{wt[i]}")
    
    print("Average TAT : ",sum(tat)/n)
    print("Average WT  : ",sum(wt)/n)


if __name__ == "__main__":

    processes = [1,2,3,4,5]
    arrival = [2,5,1,0,4]
    burst = [3,3,4,4,5]
    sjf_func(processes,arrival,burst)
