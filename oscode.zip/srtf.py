import heapq

def srtf(processes,at,bt):
    n = len(processes)

    ct = [0]*n
    tat = [0]*n
    wt = [0]*n

    completed = 0
    time = 0
    remaining_time = bt[:]

    min_heap = []

    while completed < n:

        for i in range(n):
            if at[i] <= time and remaining_time[i]>0 and (i not in [p[1] for p in min_heap]):
                heapq.heappush(min_heap,(remaining_time[i],i))

        if min_heap:

            current_burst,current_process = heapq.heappop(min_heap)

            time += 1
            remaining_time[current_process] -= 1

            if remaining_time[current_process] == 0:
                ct[current_process] = time
                tat[current_process] = ct[current_process] - at[current_process]
                wt[current_process] = tat[current_process] - bt[current_process]
                completed += 1


        else:
            time += 1

    return ct,tat,wt

def srtf_func(processes,at,bt):
    n = len(processes)

    ct,tat,wt = srtf(processes,at,bt)

    print('Processes\tArrival Time\tBurst Time\tCompletion Time\tTurnaround Time\tWaiting Time')

    for i in range(n):
        print(f"{processes[i]} \t\t{at[i]} \t\t{bt[i]} \t\t{ct[i]} \t\t{tat[i]} \t\t{wt[i]}")

    print("Average TAT : ",sum(tat)/n)
    print("Average WT  : ",sum(wt)/n)




if __name__ == "__main__":

    processes = [1,2,3,4]
    at = [0,1,2,3]
    bt = [7,4,1,4]

    srtf_func(processes,at,bt)
