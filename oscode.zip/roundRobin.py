def compute_times(processes,n,at,bt,tq):
    
    ct = [0]*n
    tat = [0]*n
    wt = [0]*n

    time = 0
    completed = 0
    r_time = bt[:]
    ready = []

    for i in range(n):
        if at[i] <= time:
            ready.append(i)
        
    while completed < n:
        if not ready:
            time += 1
            continue

        current = ready.pop(0)

        if r_time[current] <= tq:
            time += r_time[current]
            ct[current] = time
            tat[current] = ct[current] - at[current]
            wt[current] = tat[current] - bt[current]
            completed += 1
            r_time[current] = 0

        else:
            time += tq
            r_time[current] -= tq
        
        for i in range(n):
            if at[i] <= time and r_time[i] > 0 and i not in ready:
                ready.append(i)
        
        if r_time[current] > 0:
            ready.append(current)
    
    return ct, tat, wt

def round_robin(processes,at,bt,tq):
    n = len(processes)

    ct, tat, wt = compute_times(processes, n, at, bt, tq)

    print('Processes\tArrival Time\tBurst Time\tCompletion Time\tTurnaround Time\tWaiting Time')

    for i in range(n):
        print(f"{processes[i]} \t\t{at[i]} \t\t{bt[i]} \t\t{ct[i]} \t\t{tat[i]} \t\t{wt[i]}")
    
    print("Average TAT : ",sum(tat)/n)
    print("Average WT  : ",sum(wt)/n)
    

if __name__ == "__main__":

    processes = [1,2,3,4,5]
    at = [0,1,2,3,4]
    bt = [1,4,9,10,17]

    time_quantum = 2

    round_robin(processes,at,bt,time_quantum)

