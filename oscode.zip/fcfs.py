def compute_completion_time(n,processes, at, bt):
    ct = [0]*n
    time = 0

    for i in range(n):
        if time < at[i]:
            time = at[i]
        ct[i] = time + bt[i]
        time = ct[i]
    return ct
    

def compute_turnaround_time(n,at,ct):
    tat = [0]*n
    for i in range(n):
        tat[i] = ct[i] - at[i]
    return tat

def compute_waiting_time(n,tat,bt):
    wt = [0]*n
    for i in range(n):
        wt[i] = tat[i] - bt[i]
    return wt

def fcfs(n,processes,at,bt):

    s_processes = sorted(range(n), key=lambda i:at[i])
    s_arrival = [at[i] for i in s_processes]
    s_burst = [bt[i] for i in s_processes]
    
    completion_time = compute_completion_time(n,s_processes,s_arrival,s_burst)
    tat = compute_turnaround_time(n,s_arrival,completion_time)
    wt = compute_waiting_time(n,tat,s_burst)

    print("Process \tArrival Time \tBurst Time \tCompletion Time \tTAT \tWT")

    for i in range(n):
        print(f"P{s_processes[i]+1} \t\t{s_arrival[i]} \t\t{s_burst[i]} \t\t{completion_time[i]} \t\t\t{tat[i]} \t{wt[i]}")

    print("Average Waiting Time: ",sum(wt)/n)
    print("Average TAT  : ",sum(tat)/n)

if __name__ == "__main__":

    processes = [1,2,3,4]
    at = [0,1,5,6]
    bt = [2,2,3,4]

    n = len(processes)

    fcfs(n,processes,at,bt)
