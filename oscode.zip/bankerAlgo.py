def is_safe(available, max_demand, allocated):

    num_processes = len(max_demand)
    num_resources = len(available)

    need = [[max_demand[i][j] - allocated[i][j] for j in range(num_resources)] for i in range(num_processes)]

    finished = [False]*num_processes
    
    safe_sequence = []
    work = available[:]

    while len(safe_sequence) < num_processes:
        found = False

        for i in range(num_processes):
            if not finished[i] and all(need[i][j] <= work[j] for j in range(num_resources)):
                for j in range(num_resources):
                    work[j] += allocated[i][j]
                
                safe_sequence.append(i)
                finished[i] = True
                found = True
                break 
        if not found:
            return False, []
    
    return True, safe_sequence

def request_resources(process_num , request, available, max_demand, allocated):

    num_resources = len(available)

    need = [max_demand[process_num][j] - allocated[process_num][j] for j in range(num_resources)]

    if any(request[j] > need[j] for j in range(num_resources)):
        print(f"Process {process_num} requested more resources")
        return False
    
    if any(request[j] > available[j] for j in range(num_resources)):
        print(f"Process {process_num} must wait")
        return False

    for j in range(num_resources):
        available[j] -= request[j]
        allocated[process_num][j] += request[j]

    safe , _ = is_safe(available, max_demand, allocated)
    if not safe:
        for j in range(num_resources):
            available[j] += request[j]
            allocated[process_num][j] -= request[j]
        print(f"Process {process_num}'s request cannot be granted as it leads to unsafe state")
        return False

    print(f"Process {process_num}'s request has been granted")
    return True

if __name__ == "__main__":

    available = [3,3,2]

    max_demand = [
        [7, 5, 3],
        [3, 2, 2],
        [9, 0, 2],
        [2, 2, 2],
        [4, 3, 3]
    ]

    allocated = [
        [0, 1, 0],
        [2, 0, 0],
        [3, 0, 2],
        [2, 1, 1],
        [0, 0, 2]
    ]

    safe, safe_sequence = is_safe(available, max_demand, allocated)

    if safe:
        print("The system is in safe state")
        print(f"Safe sequence : {safe_sequence}")
    
    else:
        print("The system is in an unsafe state")
    
    process_num = 1
    request = [1, 0, 2]
    request_resources(process_num, request, available, max_demand, allocated)