import heapq
def compute_time(n,processes, at, bt, priority):
    
    ct = [0]*n
    tat = [0]*n
    wt = [0]*n
            
    remaining_time = bt[:]
    completed = 0
    time = 0
    is_completed = [False]*n
    current = -1

    min_heap = []

    while completed < n:

        for i in range(n):
            if at[i] <= time and not is_completed[i]:
                heapq.heappush(min_heap,(priority[i],i))
        
        if min_heap:
            current_priority, new_process = heapq.heappop(min_heap)

            if current != new_process:
                current = new_process
            
            remaining_time[current] -= 1
            time += 1

            if remaining_time[current] == 0:
                ct[current] = time 
                tat[current] = ct[current] - at[current]
                wt[current] = tat[current] - bt[current]
                is_completed[current] = True
                completed += 1
                current = -1
        else:
            time += 1

    return ct, tat, wt

def priority_preemptive(processes,at, bt, priority):
    n = len(processes)

    completion_time, turnaround_time, waiting_time = compute_time(n, processes, at, bt, priority)

    print("Processes\tArrival Time\tBurst Time\tPriority\tCompletion Time\tTurnaround Time\tWaiting Time")
    for i in range(n):
        print(f"{processes[i]}\t\t{at[i]}\t\t{bt[i]}\t\t{priority[i]}\t\t{completion_time[i]}\t\t{turnaround_time[i]}\t\t{waiting_time[i]}")
    
    # Calculate average times
    print("Average Turnaround Time:", sum(turnaround_time) / n)
    print("Average Waiting Time:", sum(waiting_time) / n)

if __name__ == "__main__":
    
    processes = [1,2,3,4,5]
    at = [0,2,1,4,5]
    bt = [7,4,2,5,6]
    priority = [3,1,0,4,2] # Priority of each process (lower number = higher priority)
    
    # Call the preemptive priority scheduling function
    priority_preemptive(processes, at, bt, priority)
