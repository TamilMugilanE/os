#Priority scheduling

def compute_time(n,processes,at,bt,priority):
    
    ct = [0]*n
    tat = [0]*n
    wt = [0]*n

    completed = 0
    time = 0
    is_completed = [False]*n

    while completed < n:

        idx = -1
        h_priority = float('inf')

        for i in range(n):
            if at[i] <= time and not is_completed[i]:
                if priority[i] < h_priority:
                    h_priority = priority[i]
                    idx = i
                elif priority[i] == h_priority and at[i] < at[idx]:
                    idx = i
        
        if idx != -1:
            ct[idx] = time + bt[idx]
            tat[idx] = ct[idx] - at[idx]
            wt[idx] = tat[idx] - bt[idx]
            time += bt[idx]
            completed += 1
            is_completed[idx] = True
        
        else:
            time += 1



    return ct, tat, wt

def priority_scheduling(processes,at,bt,priority):
    
    n = len(processes)

    ct, tat, wt = compute_time(n,processes,at,bt,priority)

    print('Processes\tArrival Time\tBurst Time\tPriority\tCompletion Time\tTurnaround Time\tWaiting Time')

    for i in range(n):
        print(f"{processes[i]} \t\t{at[i]} \t\t{bt[i]} \t\t{priority[i]} \t\t{ct[i]} \t\t{tat[i]} \t\t{wt[i]}")

    print("Average TAT : ",sum(tat)/n)
    print("Average WT  : ",sum(wt)/n)

if __name__ == "__main__":

    processes = [1,2,3,4,5]
    at = [0,2,1,4,5]
    bt = [7,4,2,5,6]
    priority = [3,1,0,4,2]

    priority_scheduling(processes,at,bt,priority)