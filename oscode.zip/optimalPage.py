def optimal(page_frames, pages): 
    frames = []
    page_faults = 0
    page_hits = 0 
    memory_state = [] 
    summary = {'page_faults': 0,'page_hits': 0}
    for i in range(len(pages)): 
        page = pages[i]
        status = ''
        if page not in frames:
            if len(frames) < page_frames: 
                frames.append(page)
            else:
                farthest = -1
                index_to_replace = -1

                # Find the page that is not going to be used for the longest
                for j in range(len(frames)):
                    try:
                        next_use = pages.index(frames[j], i + 1)
                    except ValueError:
                        next_use = float('inf')  # If the page doesn't appear

                    if next_use > farthest: 
                        farthest = next_use 
                        index_to_replace = j
                frames[index_to_replace] = page 
            page_faults += 1
            status = 'Fault'
        else:
            page_hits += 1 
            status = 'Hit'

        memory_state.append(list(frames)) 
        summary['page_faults'] = page_faults 
        summary['page_hits'] = page_hits

    return memory_state, summary

def print_table(memory_state, summary):
    print(f"{'Page Req':<10}{'Memory State':<30}{'Status'}") 
    for i, state in enumerate(memory_state): 
        state_str = str(state)
        status = 'Fault' if i < summary['page_faults'] else 'Hit' 
        print(f"{i+1:<10}{state_str:<30}{status}")

    print("\nSummary:")
    total_requests = len(memory_state)
    hit_ratio = summary['page_hits'] / total_requests 
    fault_ratio = summary['page_faults'] / total_requests 
    print(f"Total Page Faults: {summary['page_faults']}")
    print(f"Total Page Hits: {summary['page_hits']}") 
    print(f"Hit Ratio: {hit_ratio:.2f}")
    print(f"Fault Ratio: {fault_ratio:.2f}")

# Test Optimal
page_frames = 3
pages = [7, 0, 1, 2, 0, 3, 0, 4, 2, 3]
memory_state, summary = optimal(page_frames, pages) 
print_table(memory_state, summary)
